package patron_observer;

public interface Observador {

	void actualiza();
}
