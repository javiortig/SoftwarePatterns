package sol_con_interfaz;

public interface IObservador {

	void actualiza(String descripcion, double precio);
}
